import json
import os
import re
import shutil
import time
import traceback
import urllib.request
import zipfile

from qgis.PyQt.QtCore import QVariant
from qgis.core import (
    Qgis, QgsCoordinateReferenceSystem, QgsCoordinateTransform,
    QgsCoordinateTransformContext, QgsFeature, QgsField, QgsFields, QgsGeometry,
    QgsMessageLog, QgsTask, QgsVectorFileWriter, QgsVectorLayer, QgsWkbTypes
)

CATEGORIA = "INEGI Downloader"
MALLA = os.path.join(os.path.dirname(__file__), "malla_50k.geojson")
URL_INEGI = "https://www.inegi.org.mx/programas/topografia/50000/#descargas"
CAMPOS = ("geografico", "elevacion", "nombre")
CAMPO_BUSQUEDA = "input#bcm_resultBusqueda3_input_search"
BOTON_BUSQUEDA = "button#bcm_buscar_btn_resultBusqueda3"


def _log(mensaje, nivel=Qgis.Info):
    QgsMessageLog.logMessage(mensaje, CATEGORIA, nivel)


def _wkt_multipoligono(geometria):
    poligonos = geometria["coordinates"] if geometria["type"] == "MultiPolygon" else [geometria["coordinates"]]
    return "MULTIPOLYGON(" + ",".join(
        "(" + ",".join("(" + ",".join(f"{c[0]} {c[1]}" for c in anillo) + ")" for anillo in poligono) + ")"
        for poligono in poligonos) + ")"


def _cargar_malla():
    with open(MALLA, encoding="utf-8") as archivo:
        datos = json.load(archivo)
    return [(f["properties"]["CLAVE50K"], QgsGeometry.fromWkt(_wkt_multipoligono(f["geometry"])))
            for f in datos["features"]]


def _coincide(archivo, deseado):
    if archivo == deseado:
        return True
    a = re.match(r"^(.+)50_([pla])$", archivo)
    d = re.match(r"^(.+)50_([pla])$", deseado)
    if not a or not d or a.group(2) != d.group(2):
        return False
    pa, pd = a.group(1), d.group(1)
    return min(len(pa), len(pd)) >= 8 and (pa.startswith(pd) or pd.startswith(pa))


def _a_multi(geometria, tipo):
    if QgsWkbTypes.geometryType(geometria.wkbType()) != tipo:
        partes = [p for p in geometria.asGeometryCollection()
                  if QgsWkbTypes.geometryType(p.wkbType()) == tipo]
        if not partes:
            return None
        geometria = QgsGeometry.collectGeometry(partes)
    geometria.get().dropZValue()
    geometria.get().dropMValue()
    if not QgsWkbTypes.isMultiType(geometria.wkbType()):
        geometria.convertToMultiType()
    return geometria


class InegiScrapingTask(QgsTask):
    def __init__(self, description, zona_wkt_list, zona_crs, id_valor,
                 serie_deseada, capas_deseadas, carpeta_destino):
        super().__init__(description, QgsTask.CanCancel)
        self.zona_wkt_list = zona_wkt_list
        self.zona_crs = zona_crs
        self.id_valor = (id_valor or "AOI").strip() or "AOI"
        self.serie_deseada = (serie_deseada or "III").strip()
        self.capas_deseadas = [c.lower().replace(".shp", "") for c in capas_deseadas]
        self.carpeta_destino = carpeta_destino
        self.archivos_salida = []
        self.mensaje_error = None

    def run(self):
        try:
            self.setProgress(2)
            lcc = QgsCoordinateReferenceSystem("EPSG:6372")
            transformacion = QgsCoordinateTransform(
                QgsCoordinateReferenceSystem(self.zona_crs), lcc, QgsCoordinateTransformContext())
            geometrias = []
            for wkt in self.zona_wkt_list:
                g = QgsGeometry.fromWkt(wkt)
                g.transform(transformacion)
                geometrias.append(g)
            zona = QgsGeometry.unaryUnion(geometrias)
            if not zona.isGeosValid():
                zona = zona.makeValid()

            self.setProgress(6)
            caja = zona.boundingBox()
            claves = sorted({clave for clave, g in _cargar_malla()
                             if g.boundingBox().intersects(caja) and g.intersects(zona)})
            if not claves:
                self.mensaje_error = "Ninguna carta 1:50,000 intersecta la zona indicada."
                return False
            _log(f"Claves: {claves}")
            self.setProgress(10)

            enlaces = self._buscar_enlaces(claves)
            if self.isCanceled():
                return False
            enlaces = {k: v for k, v in enlaces.items() if k[1] == self.serie_deseada}
            if not enlaces:
                self.mensaje_error = f"Ninguna carta tiene la Serie '{self.serie_deseada}' disponible."
                return False
            self.setProgress(50)

            carpeta_zip = os.path.join(self.carpeta_destino, "CARTAS_TOPOGRAFICAS")
            os.makedirs(carpeta_zip, exist_ok=True)
            carpetas = []
            for i, ((clave, serie), enlace) in enumerate(sorted(enlaces.items())):
                if self.isCanceled():
                    return False
                ruta_zip = os.path.join(carpeta_zip, f"{clave}_{serie}.zip")
                try:
                    self._descargar(enlace, ruta_zip)
                    carpeta = os.path.join(carpeta_zip, f"{clave}_{serie}")
                    os.makedirs(carpeta, exist_ok=True)
                    with zipfile.ZipFile(ruta_zip, "r") as zf:
                        zf.extractall(carpeta)
                    carpetas.append(carpeta)
                except Exception as e:
                    _log(f"No se pudo obtener {clave}: {e}", Qgis.Warning)
                self.setProgress(50 + int((i + 1) / len(enlaces) * 25))

            if not carpetas:
                self.mensaje_error = "No se pudo descargar ninguna carta."
                return False

            self.archivos_salida = self._recortar(zona, lcc, carpetas)
            self.setProgress(100)
            if not self.archivos_salida and not self.isCanceled():
                self.mensaje_error = "El proceso termino sin generar capas."
            return len(self.archivos_salida) > 0

        except Exception as e:
            self.mensaje_error = str(e)
            _log(f"{e}\n{traceback.format_exc()}", Qgis.Critical)
            return False

    def _crear_driver(self):
        from selenium import webdriver
        opciones = webdriver.ChromeOptions()
        opciones.add_argument("--headless=new")
        opciones.add_argument("--disable-gpu")
        return webdriver.Chrome(options=opciones)

    def _buscar_enlaces(self, claves):
        from selenium.webdriver.common.by import By
        from selenium.webdriver.support import expected_conditions as EC
        from selenium.webdriver.support.ui import WebDriverWait

        try:
            driver = self._crear_driver()
        except Exception as e:
            raise RuntimeError(f"No se pudo iniciar Google Chrome. Verifica que este instalado. {e}")

        enlaces = {}

        def buscar(clave):
            caja = driver.find_element(By.CSS_SELECTOR, CAMPO_BUSQUEDA)
            boton = driver.find_element(By.CSS_SELECTOR, BOTON_BUSQUEDA)
            driver.execute_script("arguments[0].scrollIntoView();", caja)
            driver.execute_script("arguments[0].scrollIntoView();", boton)
            caja.clear()
            caja.send_keys(clave)
            WebDriverWait(driver, 100).until(EC.element_to_be_clickable((By.CSS_SELECTOR, BOTON_BUSQUEDA)))
            driver.execute_script("arguments[0].click();", boton)
            WebDriverWait(driver, 100).until(EC.presence_of_element_located((By.CSS_SELECTOR, "tbody")))

        def serie_de(fila):
            try:
                texto = fila.find_element(By.CSS_SELECTOR, "td:nth-child(4) .tablesaw-cell-content").text.strip()
                return texto or "Sin Serie"
            except Exception:
                return "Sin Serie"

        def leer_filas():
            for fila in driver.find_elements(By.CSS_SELECTOR, "tbody tr"):
                try:
                    clave = fila.find_element(By.CSS_SELECTOR, "td:nth-child(1) .tablesaw-cell-content").text.strip()
                    serie = serie_de(fila)
                    for i in (8, 9, 10):
                        try:
                            fila.find_element(By.CSS_SELECTOR, f'td:nth-child({i}) img[src="/img/ico/ico_shp.png"]')
                            href = fila.find_element(
                                By.CSS_SELECTOR, f'td:nth-child({i}) a[href$=".zip"]').get_attribute("href")
                            enlaces[(clave, serie)] = href
                            break
                        except Exception:
                            continue
                except Exception:
                    continue

        try:
            driver.get(URL_INEGI)
            WebDriverWait(driver, 100).until(EC.presence_of_element_located((By.CSS_SELECTOR, CAMPO_BUSQUEDA)))
            for i, clave in enumerate(claves):
                if self.isCanceled():
                    break
                buscar(clave)
                time.sleep(15)
                altura = driver.execute_script("return document.body.scrollHeight")
                while not self.isCanceled():
                    leer_filas()
                    driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
                    time.sleep(20)
                    nueva = driver.execute_script("return document.body.scrollHeight")
                    if nueva == altura:
                        break
                    altura = nueva
                self.setProgress(10 + int((i + 1) / len(claves) * 40))
        finally:
            driver.quit()
        return enlaces

    def _descargar(self, url, ruta):
        solicitud = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(solicitud, timeout=300) as respuesta, open(ruta, "wb") as salida:
            shutil.copyfileobj(respuesta, salida, 32768)

    def _recortar(self, zona, lcc, carpetas):
        rutas = {}
        for carpeta in carpetas:
            conjunto = os.path.join(carpeta, "conjunto_de_datos")
            for raiz, _, archivos in os.walk(conjunto):
                for archivo in archivos:
                    if not archivo.lower().endswith(".shp"):
                        continue
                    nombre = archivo[:-4].lower()
                    for deseado in self.capas_deseadas:
                        if _coincide(nombre, deseado):
                            rutas.setdefault(deseado, []).append(os.path.join(raiz, archivo))
                            break

        faltantes = [c for c in self.capas_deseadas if c not in rutas]
        if faltantes:
            _log("Capas no encontradas en las cartas: " + ", ".join(faltantes), Qgis.Warning)

        motor = QgsGeometry.createGeometryEngine(zona.constGet())
        motor.prepareGeometry()

        salidas = []
        for i, (deseado, lista) in enumerate(rutas.items()):
            if self.isCanceled():
                break
            salida = self._escribir(deseado, lista, zona, motor, lcc)
            if salida:
                salidas.append(salida)
            self.setProgress(75 + int((i + 1) / len(rutas) * 25))
        return salidas

    def _escribir(self, deseado, rutas, zona, motor, lcc):
        contexto = QgsCoordinateTransformContext()
        caja = zona.boundingBox()
        capas = []
        tipo = None
        campos = QgsFields()
        campos.append(QgsField("ID_ZONA", QVariant.String))

        for ruta in rutas:
            capa = QgsVectorLayer(ruta, "origen", "ogr")
            if not capa.isValid() or not capa.crs().isValid():
                _log(f"No se pudo leer {ruta}", Qgis.Warning)
                continue
            capas.append(capa)
            if tipo is None:
                tipo = QgsWkbTypes.geometryType(capa.wkbType())
            for nombre in CAMPOS:
                indice = capa.fields().lookupField(nombre)
                if indice >= 0 and campos.indexFromName(nombre) < 0:
                    origen = capa.fields().at(indice)
                    campos.append(QgsField(nombre, origen.type(), origen.typeName(),
                                           origen.length(), origen.precision()))

        if not capas:
            return None

        multi = {QgsWkbTypes.PointGeometry: "MultiPoint",
                 QgsWkbTypes.LineGeometry: "MultiLineString",
                 QgsWkbTypes.PolygonGeometry: "MultiPolygon"}[tipo]
        memoria = QgsVectorLayer(f"{multi}?crs=EPSG:6372", deseado, "memory")
        memoria.dataProvider().addAttributes(campos.toList())
        memoria.updateFields()

        nuevos = []
        for capa in capas:
            transformacion = QgsCoordinateTransform(capa.crs(), lcc, contexto)
            indices = {n: capa.fields().lookupField(n) for n in CAMPOS}
            for entidad in capa.getFeatures():
                geometria = entidad.geometry()
                if geometria.isNull() or geometria.isEmpty():
                    continue
                geometria = QgsGeometry(geometria)
                geometria.transform(transformacion)
                if not geometria.boundingBox().intersects(caja):
                    continue
                try:
                    if not geometria.isGeosValid():
                        geometria = geometria.makeValid()
                    if not motor.intersects(geometria.constGet()):
                        continue
                    resultado = motor.intersection(geometria.constGet())
                except Exception:
                    continue
                if resultado is None:
                    continue
                corte = _a_multi(QgsGeometry(resultado), tipo)
                if corte is None or corte.isEmpty():
                    continue
                nueva = QgsFeature(memoria.fields())
                nueva.setGeometry(corte)
                nueva.setAttribute("ID_ZONA", self.id_valor)
                for nombre, indice in indices.items():
                    if indice >= 0:
                        nueva.setAttribute(nombre, entidad[indice])
                nuevos.append(nueva)

        if not nuevos:
            return None
        memoria.dataProvider().addFeatures(nuevos)
        memoria.updateExtents()

        nombre_salida = f"{self.id_valor}_{deseado.upper()}_INEGI_Serie_{self.serie_deseada}.geojson"
        ruta_salida = os.path.join(self.carpeta_destino, nombre_salida)
        opciones = QgsVectorFileWriter.SaveVectorOptions()
        opciones.driverName = "GeoJSON"
        opciones.fileEncoding = "UTF-8"
        resultado = QgsVectorFileWriter.writeAsVectorFormatV2(memoria, ruta_salida, contexto, opciones)
        if resultado[0] != QgsVectorFileWriter.NoError:
            _log(f"No se pudo escribir {ruta_salida}: {resultado[1]}", Qgis.Warning)
            return None
        return ruta_salida
