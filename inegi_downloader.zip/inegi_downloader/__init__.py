import os
import sys

_LIBS = os.path.join(os.path.dirname(__file__), "libs")
try:
    os.makedirs(_LIBS, exist_ok=True)
except OSError:
    pass
if _LIBS not in sys.path:
    sys.path.append(_LIBS)


def classFactory(iface):
    from .inegi_downloader import InegiDownloaderPlugin
    return InegiDownloaderPlugin(iface)
