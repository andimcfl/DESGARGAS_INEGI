# INEGI Cartas Topograficas Downloader

## Requisitos del sistema
- QGIS Desktop 3.16 o superior
- Google Chrome o Chromium instalado (version 109+)
- Conexion a internet sin bloqueo hacia inegi.org.mx, pypi.org y files.pythonhosted.org
- Permiso de escritura en la carpeta de complementos de QGIS

## Instalacion de dependencias
- Necesita conexion a internet la primera vez
- Si falla, ejecuta en OSGeo4W Shell (Windows) o terminal:
  `python -m pip install --target "<carpeta del plugin>/libs" "selenium>=4.10,<4.35"`

## Instalar el plugin en QGIS
Complementos > Administrar e instalar complementos > Instalar a partir de ZIP

## Uso
1. Carga en QGIS la capa de poligonos que define tu zona de interes.
2. Si solo quieres una parte, selecciona las entidades y marca Usar solo las entidades seleccionadas.
3. Elige el campo cuyo valor sera el prefijo de los archivos de salida.
4. Elige la Serie (ej. `III`), palomea las capas a extraer y elige la carpeta destino.
5. Ejecuta y espera el progreso en la barra de tareas, puede tardar mucho.
6. Al terminar, las capas recortadas se agregan al proyecto.
