import os
import sys
import importlib
import subprocess

from qgis.core import Qgis, QgsMessageLog, QgsTask

CATEGORIA = "INEGI Downloader"
LIBS = os.path.join(os.path.dirname(__file__), "libs")
REQUISITO = "selenium>=4.10,<4.35"


def selenium_disponible():
    if LIBS not in sys.path:
        sys.path.append(LIBS)
    importlib.invalidate_caches()
    try:
        importlib.import_module("selenium.webdriver")
        importlib.import_module("selenium.webdriver.common.by")
        return True
    except Exception:
        return False


def _python():
    actual = sys.executable
    if actual and os.path.basename(actual).lower().startswith("python"):
        return actual
    nombres = ("python3.exe", "python.exe") if os.name == "nt" else ("bin/python3", "bin/python")
    for base in (sys.exec_prefix, sys.base_exec_prefix):
        for nombre in nombres:
            ruta = os.path.join(base, nombre)
            if os.path.exists(ruta):
                return ruta
    return None


def instalar_selenium():
    os.makedirs(LIBS, exist_ok=True)
    argumentos = ["install", "--upgrade", "--prefer-binary", "--disable-pip-version-check",
                  "--no-warn-script-location", "--target", LIBS, REQUISITO]
    python = _python()
    detalle = ""
    if python:
        bandera = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
        for intento in range(2):
            r = subprocess.run([python, "-m", "pip"] + argumentos, capture_output=True,
                               text=True, timeout=900, creationflags=bandera)
            if r.returncode == 0:
                return True, ""
            detalle = r.stderr or r.stdout
            if intento == 0 and "No module named pip" in detalle:
                subprocess.run([python, "-m", "ensurepip", "--default-pip"], capture_output=True,
                               text=True, timeout=300, creationflags=bandera)
                continue
            break
    try:
        from pip._internal.cli.main import main
        if main(argumentos) == 0:
            return True, ""
    except Exception as e:
        detalle += f"\n{e}"
    return False, detalle


class TareaDependencias(QgsTask):
    def __init__(self):
        super().__init__("INEGI Downloader: instalando componentes")

    def run(self):
        exito, detalle = instalar_selenium()
        if not exito:
            QgsMessageLog.logMessage(detalle, CATEGORIA, Qgis.Critical)
            return False
        return selenium_disponible()
