import os

from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QAction, QMessageBox
from qgis.core import QgsApplication, QgsProject, QgsTask, QgsVectorLayer

from .dependencias import TareaDependencias, selenium_disponible
from .inegi_downloader_dialog import InegiDownloaderDialog
from .scraping_task import InegiScrapingTask

TITULO = "INEGI Downloader"


class InegiDownloaderPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)
        self.menu = "&INEGI Downloader"
        self.action = None
        self.dlg = None
        self.task = None
        self.tarea_deps = None

    def initGui(self):
        icono = QIcon(os.path.join(self.plugin_dir, "icon.png"))
        self.action = QAction(icono, "Descargar cartas INEGI", self.iface.mainWindow())
        self.action.triggered.connect(self.run)
        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToMenu(self.menu, self.action)
        self._preparar_dependencias()

    def unload(self):
        self.iface.removePluginMenu(self.menu, self.action)
        self.iface.removeToolBarIcon(self.action)

    def _preparar_dependencias(self):
        if selenium_disponible():
            return True
        barra = self.iface.messageBar()
        if self.tarea_deps is not None and self.tarea_deps.status() in (QgsTask.Queued, QgsTask.Running, QgsTask.OnHold):
            barra.pushInfo(TITULO, "Instalando componentes necesarios. Intenta de nuevo en unos minutos.")
            return False
        self.tarea_deps = TareaDependencias()
        self.tarea_deps.taskCompleted.connect(
            lambda: barra.pushSuccess(TITULO, "Componentes instalados. El plugin esta listo."))
        self.tarea_deps.taskTerminated.connect(
            lambda: barra.pushCritical(TITULO, "No se pudieron instalar los componentes. Revisa tu conexion a internet y el panel de mensajes de QGIS."))
        QgsApplication.taskManager().addTask(self.tarea_deps)
        barra.pushInfo(TITULO, "Instalando componentes necesarios (solo la primera vez)...")
        return False

    def run(self):
        if not self._preparar_dependencias():
            return

        if self.dlg is None:
            self.dlg = InegiDownloaderDialog(self.iface.mainWindow())
        self.dlg._actualizar_campos()

        if not self.dlg.exec_():
            return

        zona_wkt_list = self.dlg.get_zona_wkt_list()
        zona_crs = self.dlg.get_zona_crs()
        id_valor = self.dlg.get_id_valor()
        serie = self.dlg.get_serie()
        capas = self.dlg.get_capas()
        carpeta_destino = self.dlg.get_output_folder()

        if not zona_wkt_list or not zona_crs:
            QMessageBox.warning(self.iface.mainWindow(), TITULO,
                                "Selecciona una capa de poligonos como zona de corte.")
            return
        if not capas:
            QMessageBox.warning(self.iface.mainWindow(), TITULO, "Marca al menos una capa.")
            return
        if not carpeta_destino:
            QMessageBox.warning(self.iface.mainWindow(), TITULO, "Indica una carpeta destino.")
            return

        self.task = InegiScrapingTask(
            description=f"Descargando cartas INEGI para '{id_valor}'",
            zona_wkt_list=zona_wkt_list,
            zona_crs=zona_crs,
            id_valor=id_valor,
            serie_deseada=serie,
            capas_deseadas=capas,
            carpeta_destino=carpeta_destino,
        )
        self.task.taskCompleted.connect(self._on_success)
        self.task.taskTerminated.connect(self._on_failure)
        QgsApplication.taskManager().addTask(self.task)
        self.iface.messageBar().pushInfo(TITULO, f"Proceso iniciado para '{id_valor}'.")

    def _on_success(self):
        archivos = self.task.archivos_salida
        for ruta in archivos:
            if os.path.exists(ruta):
                nombre = os.path.splitext(os.path.basename(ruta))[0]
                capa = QgsVectorLayer(ruta, nombre, "ogr")
                if capa.isValid():
                    QgsProject.instance().addMapLayer(capa)
        self.iface.messageBar().pushSuccess(TITULO, f"{len(archivos)} capa(s) agregadas al proyecto.")

    def _on_failure(self):
        mensaje = self.task.mensaje_error or "El proceso fallo. Revisa el panel de mensajes de QGIS."
        self.iface.messageBar().pushCritical(TITULO, mensaje)
