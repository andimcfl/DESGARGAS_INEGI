from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QPushButton,
    QFileDialog, QCheckBox, QDialogButtonBox, QComboBox, QGroupBox,
    QListWidget, QListWidgetItem
)
from qgis.core import QgsMapLayerProxyModel
from qgis.gui import QgsMapLayerComboBox

from .catalogo import CAPAS, PREDETERMINADAS

SIN_PREFIJO = "(usar 'AOI' generico)"


class InegiDownloaderDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Descargar y recortar cartas topograficas INEGI")
        self.setMinimumWidth(480)

        layout = QVBoxLayout()

        box_zona = QGroupBox("Zona de corte")
        layout_zona = QVBoxLayout()
        self.cmb_layer = QgsMapLayerComboBox()
        self.cmb_layer.setFilters(QgsMapLayerProxyModel.PolygonLayer)
        self.cmb_layer.layerChanged.connect(self._actualizar_campos)
        layout_zona.addWidget(self.cmb_layer)

        self.chk_solo_seleccionadas = QCheckBox("Usar solo las entidades seleccionadas")
        layout_zona.addWidget(self.chk_solo_seleccionadas)

        layout_zona.addWidget(QLabel("Campo para el prefijo de los archivos:"))
        self.cmb_id_field = QComboBox()
        layout_zona.addWidget(self.cmb_id_field)

        self.lbl_conteo = QLabel("")
        layout_zona.addWidget(self.lbl_conteo)
        box_zona.setLayout(layout_zona)
        layout.addWidget(box_zona)

        box_descarga = QGroupBox("Descarga INEGI")
        layout_descarga = QVBoxLayout()

        fila_serie = QHBoxLayout()
        fila_serie.addWidget(QLabel("Serie:"))
        self.cmb_serie = QComboBox()
        self.cmb_serie.setEditable(True)
        self.cmb_serie.addItems(["III", "II", "I"])
        fila_serie.addWidget(self.cmb_serie)
        layout_descarga.addLayout(fila_serie)

        self.lst_capas = QListWidget()
        self.lst_capas.setMinimumHeight(220)
        for nombre, archivo in CAPAS:
            item = QListWidgetItem(nombre)
            item.setFlags(item.flags() | Qt.ItemIsUserCheckable)
            item.setCheckState(Qt.Checked if archivo in PREDETERMINADAS else Qt.Unchecked)
            item.setData(Qt.UserRole, archivo)
            self.lst_capas.addItem(item)
        layout_descarga.addWidget(self.lst_capas)

        fila_marcas = QHBoxLayout()
        for texto, accion in (("Todas", lambda: self._marcar(lambda a: True)),
                              ("Ninguna", lambda: self._marcar(lambda a: False)),
                              ("Predeterminadas", lambda: self._marcar(lambda a: a in PREDETERMINADAS))):
            boton = QPushButton(texto)
            boton.clicked.connect(accion)
            fila_marcas.addWidget(boton)
        layout_descarga.addLayout(fila_marcas)

        box_descarga.setLayout(layout_descarga)
        layout.addWidget(box_descarga)

        layout.addWidget(QLabel("Carpeta destino:"))
        fila_carpeta = QHBoxLayout()
        self.txt_carpeta = QLineEdit()
        btn_carpeta = QPushButton("Examinar...")
        btn_carpeta.clicked.connect(self._elegir_carpeta)
        fila_carpeta.addWidget(self.txt_carpeta)
        fila_carpeta.addWidget(btn_carpeta)
        layout.addLayout(fila_carpeta)

        botones = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        botones.accepted.connect(self.accept)
        botones.rejected.connect(self.reject)
        layout.addWidget(botones)

        self.setLayout(layout)
        self._actualizar_campos()

    def _marcar(self, criterio):
        for i in range(self.lst_capas.count()):
            item = self.lst_capas.item(i)
            item.setCheckState(Qt.Checked if criterio(item.data(Qt.UserRole)) else Qt.Unchecked)

    def _actualizar_campos(self):
        self.cmb_id_field.clear()
        self.cmb_id_field.addItem(SIN_PREFIJO)
        capa = self.cmb_layer.currentLayer()
        if capa is None:
            self.lbl_conteo.setText("")
            return
        for campo in capa.fields():
            self.cmb_id_field.addItem(campo.name())
        self.lbl_conteo.setText(
            f"{capa.featureCount()} entidades, {capa.selectedFeatureCount()} seleccionadas.")

    def _elegir_carpeta(self):
        carpeta = QFileDialog.getExistingDirectory(self, "Selecciona carpeta destino")
        if carpeta:
            self.txt_carpeta.setText(carpeta)

    def _entidades(self):
        capa = self.cmb_layer.currentLayer()
        if capa is None:
            return []
        if self.chk_solo_seleccionadas.isChecked() and capa.selectedFeatureCount() > 0:
            return capa.selectedFeatures()
        return list(capa.getFeatures())

    def get_zona_wkt_list(self):
        return [f.geometry().asWkt() for f in self._entidades()
                if not f.geometry().isNull() and not f.geometry().isEmpty()]

    def get_zona_crs(self):
        capa = self.cmb_layer.currentLayer()
        return capa.crs().authid() if capa else None

    def get_id_valor(self):
        campo = self.cmb_id_field.currentText()
        entidades = self._entidades()
        if campo == SIN_PREFIJO or not entidades:
            return "AOI"
        valor = entidades[0][campo]
        return str(valor) if valor is not None and str(valor) != "NULL" else "AOI"

    def get_serie(self):
        return self.cmb_serie.currentText().strip() or "III"

    def get_capas(self):
        return [self.lst_capas.item(i).data(Qt.UserRole)
                for i in range(self.lst_capas.count())
                if self.lst_capas.item(i).checkState() == Qt.Checked]

    def get_output_folder(self):
        return self.txt_carpeta.text().strip()
